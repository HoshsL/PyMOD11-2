"""
pymod112
一个可以离线检验公民身份号码是否合法的程序
v 0.1.0
"""

from .mod112 import *

__title__ = 'pymod112'
__version__ = '0.1.0'
__author__ = 'HoshsL'

